// Verified against: ClipContext.java (26.1.2)
package net.instantgratification.magnet;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BushBlock;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class SecondaryVisionCheck {

    /**
     * Performs a granular block state check if the primary PlayerVisionTracker passes.
     * This avoids expensive raycasts against every solid wall, only checking when
     * the path is otherwise clear or contains non-visual solids (like glass).
     */
    public static boolean canSee(Player player, Entity target, boolean blockTransparent, boolean blockFlora, boolean blockEntities) {
        // If no granular blocking rules are active, skip the secondary check to save TPS
        if (!blockTransparent && !blockFlora && !blockEntities) {
            return true;
        }

        Level level = player.level();
        Vec3 start = player.getEyePosition();
        Vec3 end = new Vec3(target.getX(), target.getY() + target.getBbHeight() / 2.0, target.getZ());
        CollisionContext collisionContext = CollisionContext.of(player);

        Boolean result = BlockGetter.traverseBlocks(start, end, null, (ctx, pos) -> {
            BlockState state = level.getBlockState(pos);

            // Skip air entirely
            if (state.isAir()) {
                return null; // continue traversing
            }

            // 1. Flora Check
            if (blockFlora) {
                if (state.getBlock() instanceof BushBlock || state.getBlock() instanceof LeavesBlock) {
                    return false; // Path blocked
                }
            }

            // 2. Block Entity Check (Chests, Beds, Shulkers, Banners, etc.)
            if (blockEntities) {
                if (state.hasBlockEntity()) {
                    return false; // Path blocked
                }
            }

            // 3. Transparent / Non-Full Block Check
            if (blockTransparent) {
                // If the visual shape is not empty, it could block.
                // Note: PlayerVisionTracker uses ClipContext.Block.VISUAL which IGNORES glass/water.
                // We want to manually test if the Visual shape interacts with the ray.
                VoxelShape visualShape = state.getVisualShape(level, pos, collisionContext);
                if (!visualShape.isEmpty()) {
                     // Need to see if our specific ray actually hits the shape, not just passes through the block's space.
                     if (visualShape.clip(start, end, pos) != null) {
                         return false; // Ray hit the non-full/transparent visual shape
                     }
                }
            }

            return null; // continue traversing
        }, (ctx) -> true); // missFactory -> true (path is clear)

        return result != null ? result : true;
    }
}
