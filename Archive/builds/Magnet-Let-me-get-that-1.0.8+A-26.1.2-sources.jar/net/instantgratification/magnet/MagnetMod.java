package net.instantgratification.magnet;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import net.instantgratification.magnet.config.MagnetConfig;
import net.instantgratification.magnet.registry.ModGameRules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MagnetMod implements ModInitializer {
    public static final String MOD_ID = "ig_magnet";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("Magnet, Let me get that! Initializing...");
        MagnetConfig.load(FabricLoader.getInstance().getConfigDir());
        ModGameRules.register();
    }
}
